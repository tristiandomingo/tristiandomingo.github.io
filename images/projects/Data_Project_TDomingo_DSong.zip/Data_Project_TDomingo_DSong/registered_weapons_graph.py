'''
Bar Graph for registered weapons
Tristian Domingo
Dain Song
Period 2
'''

import matplotlib.pyplot as plt
import os.path

# Naming the current directory
directory = os.path.dirname(os.path.abspath(__file__))  
filename = os.path.join(directory, 'weapons_income.txt')

# Create lists for x and y values
states=[]
weapons=[]
incomes = []

datafile = open(filename,'r') # 'r' means 'read-only'
next(datafile)
  
# For each line in the file...
for line in datafile:
    # Split the line into the two separate pieces of info
    state, weapon, income = line.split('\t')
    states += [state]
    weapons += [weapon]
    incomes += [income[0:-1]]            
datafile.close()

fig, ax = plt.subplots(1,1)
ax.scatter(incomes,weapons)
#ax.bar(range(51), weapons)
ax.set_ylabel('Number of Registered Weapons')
ax.set_xlabel('State Median Income')
#ax.set_xticklabels(states)
ax.set_title('Registered Weapons by State Median Income')
fig.show()